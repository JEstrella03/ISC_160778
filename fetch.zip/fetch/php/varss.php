<?php

$nombre_fichero = __DIR__."/vetnegris.sqlite3";

?>